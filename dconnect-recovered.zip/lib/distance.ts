import "server-only";
/** Road distance in km via Google Distance Matrix. Returns null when no server key is set or lookup fails. */
export async function routeDistanceKm(from: string, to: string): Promise<number | null> {
  const key = process.env.GOOGLE_MAPS_SERVER_KEY;
  if (!key) return null;
  try {
    const u = new URL("https://maps.googleapis.com/maps/api/distancematrix/json");
    u.search = new URLSearchParams({ origins: from, destinations: to, units: "metric", key }).toString();
    const r = await fetch(u, { signal: AbortSignal.timeout(8000), cache: "no-store" });
    if (!r.ok) return null;
    const d = await r.json() as { rows?: { elements?: { status: string; distance?: { value: number } }[] }[] };
    const el = d.rows?.[0]?.elements?.[0];
    return el?.status === "OK" && el.distance ? Math.round(el.distance.value / 100) / 10 : null;
  } catch { return null; }
}
