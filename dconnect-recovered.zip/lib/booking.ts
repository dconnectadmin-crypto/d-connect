import type { Prisma } from "@prisma/client";
import type { BookingDTO } from "./types";
export const bookingInclude = { rider: { select: { name: true } }, captain: { select: { name: true } } } satisfies Prisma.BookingInclude;
type Row = Prisma.BookingGetPayload<{ include: typeof bookingInclude }>;
export function toDTO(b: Row): BookingDTO {
  return { id: b.id, pickup: b.pickup, destination: b.destination, type: b.type, returnAt: b.returnAt?.toISOString() ?? null,
    category: b.category, distanceKm: b.distanceKm, total: Number(b.total), status: b.status, createdAt: b.createdAt.toISOString(),
    riderName: b.rider.name, captainName: b.captain?.name ?? null, captainId: b.captainId };
}
