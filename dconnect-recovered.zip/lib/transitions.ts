// Single source of truth for who may move a booking between statuses.
// Pure (no imports) so it is unit-testable without a database; the API route builds its atomic WHERE clauses from it.
export type Role = "RIDER" | "CAPTAIN" | "ADMIN";
export type Status = "REQUESTED" | "ACCEPTED" | "COMPLETED" | "CANCELLED";
export type Action = "accept" | "complete" | "cancel";

const RULES: Record<Action, { roles: Role[]; to: Status; from: Partial<Record<Role, Status[]>> }> = {
  accept:   { roles: ["CAPTAIN"],          to: "ACCEPTED",  from: { CAPTAIN: ["REQUESTED"] } },
  complete: { roles: ["CAPTAIN"],          to: "COMPLETED", from: { CAPTAIN: ["ACCEPTED"] } },
  cancel:   { roles: ["RIDER", "ADMIN"],   to: "CANCELLED", from: { RIDER: ["REQUESTED"], ADMIN: ["REQUESTED", "ACCEPTED"] } },
};

export const roleMayDo = (role: Role, action: Action) => RULES[action].roles.includes(role);
export const nextStatus = (action: Action): Status => RULES[action].to;
/** Statuses a booking must currently be in for this role to perform the action ([] if not allowed). */
export const allowedFrom = (role: Role, action: Action): Status[] => RULES[action].from[role] ?? [];
export const canTransition = (role: Role, action: Action, current: Status) => roleMayDo(role, action) && allowedFrom(role, action).includes(current);
