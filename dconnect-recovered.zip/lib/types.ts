export type BookingDTO = {
  id: string; pickup: string; destination: string; type: "ONE_WAY" | "ROUND_TRIP"; returnAt: string | null;
  category: string; distanceKm: number; total: number; status: "REQUESTED" | "ACCEPTED" | "COMPLETED" | "CANCELLED";
  createdAt: string; riderName: string; captainName: string | null; captainId: string | null;
};
export type LocationDTO = { captainId: string; name: string; lat: number; lng: number; heading: number | null; updatedAt: string; stale: boolean };
export type UserDTO = { id: string; name: string; email: string; role: "RIDER" | "CAPTAIN" | "ADMIN"; active: boolean; createdAt: string };
