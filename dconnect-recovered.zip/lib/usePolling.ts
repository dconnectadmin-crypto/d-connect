"use client";
import { useEffect, useRef } from "react";
/** Runs fn immediately and then every `ms` while enabled and the tab is visible. */
export function usePolling(fn: () => void | Promise<void>, ms: number, enabled = true) {
  const ref = useRef(fn);
  useEffect(() => { ref.current = fn; });
  useEffect(() => {
    if (!enabled) return;
    const run = () => { if (document.visibilityState === "visible") void ref.current(); };
    run();
    const id = setInterval(run, ms);
    document.addEventListener("visibilitychange", run);
    return () => { clearInterval(id); document.removeEventListener("visibilitychange", run); };
  }, [ms, enabled]);
}
