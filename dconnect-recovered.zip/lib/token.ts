// Edge-safe JWT helpers (used by middleware and server code).
import { SignJWT, jwtVerify } from "jose";

export type Role = "RIDER" | "CAPTAIN" | "ADMIN";
export type Session = { uid: string; role: Role };
export const COOKIE = "dc_session";
export const MAX_AGE = 60 * 60 * 24 * 7;
const isRole = (r: unknown): r is Role => r === "RIDER" || r === "CAPTAIN" || r === "ADMIN";

function key() {
  const s = process.env.SESSION_SECRET;
  if (!s || s.length < 32) throw new Error("SESSION_SECRET must be set to a random string of 32+ characters.");
  return new TextEncoder().encode(s);
}

export async function signToken(s: Session) {
  return new SignJWT({ role: s.role }).setProtectedHeader({ alg: "HS256" })
    .setSubject(s.uid).setIssuedAt().setExpirationTime(`${MAX_AGE}s`).sign(key());
}

export async function verifyToken(token: string): Promise<Session | null> {
  try {
    const { payload } = await jwtVerify(token, key(), { algorithms: ["HS256"] });
    if (!payload.sub || !isRole(payload.role)) return null;
    return { uid: payload.sub, role: payload.role };
  } catch { return null; }
}

export const roleHome = (r: Role) => (r === "ADMIN" ? "/admin" : r === "CAPTAIN" ? "/captain" : "/rider");
