// Demo pricing. Replace with your real pricing service; never trust client-computed totals.
export const RATES = { base: 40, perKm: 14, waitPerHour: 120, fee: 0.05 } as const;
export const CATEGORIES = { Mini: 1, Sedan: 1.3, SUV: 1.7 } as const;
export type Category = keyof typeof CATEGORIES;
export function quote(km: number, category: Category, roundTrip: boolean, waitHours = 0) {
  const dist = km * (roundTrip ? 2 : 1);
  const fare = (RATES.base + RATES.perKm * dist) * CATEGORIES[category];
  const wait = roundTrip ? waitHours * RATES.waitPerHour : 0;
  const fee = (fare + wait) * RATES.fee;
  return { dist, fare, wait, fee, total: fare + wait + fee };
}
