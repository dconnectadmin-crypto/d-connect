import { z } from "zod";
export const email = z.string().trim().toLowerCase().email().max(254);
export const password = z.string().min(8, "Password must be at least 8 characters").max(72);
export const loginInput = z.object({ email, password: z.string().min(1).max(72) });
export const registerInput = z.object({ name: z.string().trim().min(2).max(80), email, password });
export const adminCreateUser = registerInput.extend({ role: z.enum(["RIDER", "CAPTAIN", "ADMIN"]) });
export const bookingInput = z.object({
  pickup: z.string().trim().min(3).max(200),
  destination: z.string().trim().min(3).max(200),
  type: z.enum(["ONE_WAY", "ROUND_TRIP"]),
  returnAt: z.string().datetime().nullable().optional(),
  category: z.enum(["Mini", "Sedan", "SUV"]),
  distanceKm: z.number().min(0.5).max(2000).optional(),
  waitHours: z.number().min(0).max(48).default(0),
});
export const bookingAction = z.object({ action: z.enum(["accept", "complete", "cancel"]) });
export const locationInput = z.object({
  lat: z.number().min(-90).max(90), lng: z.number().min(-180).max(180), heading: z.number().min(0).max(360).nullable().optional(),
});
export const firstError = (e: z.ZodError) => e.issues[0]?.message ?? "Invalid input";
