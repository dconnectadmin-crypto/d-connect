export type ApiResult<T> = { ok: true; data: T } | { ok: false; error: string; status: number };
export async function api<T>(url: string, init?: RequestInit): Promise<ApiResult<T>> {
  try {
    const r = await fetch(url, { ...init, headers: { "content-type": "application/json", ...init?.headers } });
    const d = (await r.json().catch(() => ({}))) as { error?: string };
    if (r.status === 401 && typeof window !== "undefined" && !url.startsWith("/api/auth/")) {
      window.location.href = `/login?next=${encodeURIComponent(window.location.pathname)}`;
    }
    return r.ok ? { ok: true, data: d as T } : { ok: false, error: d.error ?? `Request failed (${r.status})`, status: r.status };
  } catch { return { ok: false, error: "Network error. Check your connection.", status: 0 }; }
}
