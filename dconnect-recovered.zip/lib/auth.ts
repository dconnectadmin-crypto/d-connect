import "server-only";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { db } from "./db";
import { COOKIE, MAX_AGE, signToken, verifyToken, type Role } from "./token";

export type AuthUser = { id: string; name: string; email: string; role: Role };

export async function setSessionCookie(uid: string, role: Role) {
  (await cookies()).set(COOKIE, await signToken({ uid, role }), {
    httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: MAX_AGE,
  });
}
export async function clearSessionCookie() { (await cookies()).delete(COOKIE); }

/** Current user, re-checked against the DB so deleted/disabled accounts and role changes apply immediately. */
export async function getUser(): Promise<AuthUser | null> {
  const t = (await cookies()).get(COOKIE)?.value;
  const s = t ? await verifyToken(t) : null;
  if (!s) return null;
  const u = await db.user.findUnique({ where: { id: s.uid }, select: { id: true, name: true, email: true, role: true, active: true } });
  return u && u.active ? { id: u.id, name: u.name, email: u.email, role: u.role } : null;
}

type Authz = { user: AuthUser; error?: undefined } | { error: NextResponse; user?: undefined };
export async function authorize(roles: Role[]): Promise<Authz> {
  const user = await getUser();
  if (!user) return { error: NextResponse.json({ error: "Please sign in." }, { status: 401 }) };
  if (!roles.includes(user.role)) return { error: NextResponse.json({ error: "Forbidden" }, { status: 403 }) };
  return { user };
}
