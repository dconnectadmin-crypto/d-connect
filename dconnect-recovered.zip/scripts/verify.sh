#!/usr/bin/env bash
# Phase 0 verification (macOS/Linux/Git Bash). Needs Node 22+, Docker, network. Stops at the first failure.
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] || { echo "Create .env first: cp .env.example .env  (then set SESSION_SECRET and SEED_ADMIN_PASSWORD)"; exit 1; }
set -a; . ./.env; set +a
[ -n "${DATABASE_URL:-}" ] || { echo "DATABASE_URL empty"; exit 1; }
[ "${#SESSION_SECRET}" -ge 32 ] || { echo "SESSION_SECRET must be 32+ chars"; exit 1; }
[ "${#SEED_ADMIN_PASSWORD}" -ge 10 ] || { echo "SEED_ADMIN_PASSWORD must be 10+ chars"; exit 1; }
step() { echo; echo "=== $* ==="; }
step "node version";           node -e "if (parseInt(process.versions.node) < 22) { console.error('Node 22+ required'); process.exit(1) }"
step "npm install";            npm install
step "prisma validate";        npx prisma validate
step "prisma generate";        npx prisma generate
step "tsc --noEmit";           npx tsc --noEmit
step "eslint";                 npm run lint
step "unit tests";             npm run test:unit
step "start PostgreSQL";       docker compose up -d
echo "Waiting for PostgreSQL..."
for i in $(seq 1 30); do docker compose exec -T db pg_isready -U dconnect >/dev/null 2>&1 && break; [ "$i" = 30 ] && { echo "PostgreSQL not ready: docker compose logs db"; exit 1; }; sleep 2; done
# If Prisma ever asks to RESET the database, answer NO and stop.
step "prisma migrate";         npx prisma migrate dev --name init
step "seed admin";             npm run db:seed
step "production build";       npm run build
step "integration tests"
npm run start & PID=$!
trap 'kill $PID 2>/dev/null || true' EXIT
for i in $(seq 1 30); do curl -fs http://localhost:3000/login >/dev/null 2>&1 && break; [ "$i" = 30 ] && { echo "server did not start"; exit 1; }; sleep 2; done
INTEGRATION_BASE_URL=http://localhost:3000 npm run test:integration
echo; echo "ALL CHECKS PASSED"
