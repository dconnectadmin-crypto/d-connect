import { test } from "node:test";
import assert from "node:assert/strict";
import { canTransition, allowedFrom, nextStatus, roleMayDo, type Action, type Role, type Status } from "../../lib/transitions";

const roles: Role[] = ["RIDER", "CAPTAIN", "ADMIN"];
const statuses: Status[] = ["REQUESTED", "ACCEPTED", "COMPLETED", "CANCELLED"];
const actions: Action[] = ["accept", "complete", "cancel"];

test("captain: accept only from REQUESTED, complete only from ACCEPTED", () => {
  assert.ok(canTransition("CAPTAIN", "accept", "REQUESTED"));
  assert.ok(!canTransition("CAPTAIN", "accept", "ACCEPTED"));
  assert.ok(canTransition("CAPTAIN", "complete", "ACCEPTED"));
  assert.ok(!canTransition("CAPTAIN", "complete", "REQUESTED"));
});
test("rider can cancel only before acceptance", () => {
  assert.ok(canTransition("RIDER", "cancel", "REQUESTED"));
  assert.ok(!canTransition("RIDER", "cancel", "ACCEPTED"));
});
test("admin can cancel REQUESTED or ACCEPTED, never finished bookings", () => {
  assert.ok(canTransition("ADMIN", "cancel", "REQUESTED"));
  assert.ok(canTransition("ADMIN", "cancel", "ACCEPTED"));
  assert.ok(!canTransition("ADMIN", "cancel", "COMPLETED"));
  assert.ok(!canTransition("ADMIN", "cancel", "CANCELLED"));
});
test("riders and admins can never accept or complete; captains can never cancel", () => {
  for (const r of ["RIDER", "ADMIN"] as Role[]) for (const a of ["accept", "complete"] as Action[]) assert.ok(!roleMayDo(r, a));
  assert.ok(!roleMayDo("CAPTAIN", "cancel"));
});
test("terminal states (COMPLETED, CANCELLED) allow no transition for any role/action", () => {
  for (const r of roles) for (const a of actions) for (const s of ["COMPLETED", "CANCELLED"] as Status[]) assert.ok(!canTransition(r, a, s), `${r} ${a} ${s}`);
});
test("every allowed source status is a real status and targets are correct", () => {
  for (const r of roles) for (const a of actions) for (const s of allowedFrom(r, a)) assert.ok(statuses.includes(s));
  assert.equal(nextStatus("accept"), "ACCEPTED"); assert.equal(nextStatus("complete"), "COMPLETED"); assert.equal(nextStatus("cancel"), "CANCELLED");
});
