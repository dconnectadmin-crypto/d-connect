import { test } from "node:test";
import assert from "node:assert/strict";
import { quote, RATES, CATEGORIES } from "../../lib/fare";

const near = (a: number, b: number) => assert.ok(Math.abs(a - b) < 1e-9, `${a} !== ${b}`);

test("one-way Mini: (base + perKm*km) + 5% fee", () => {
  const q = quote(10, "Mini", false);
  near(q.dist, 10); near(q.fare, 180); near(q.wait, 0); near(q.fee, 9); near(q.total, 189);
});
test("round trip doubles distance and adds waiting charge, fee applies to both", () => {
  const q = quote(10, "Mini", true, 2);
  near(q.dist, 20); near(q.fare, 320); near(q.wait, 240); near(q.fee, 28); near(q.total, 588);
});
test("waiting time is ignored for one-way trips", () => { near(quote(10, "Mini", false, 5).wait, 0); });
test("category multipliers scale the ride fare", () => {
  near(quote(10, "Sedan", false).fare, 180 * CATEGORIES.Sedan);
  near(quote(10, "SUV", false).fare, 180 * CATEGORIES.SUV);
});
test("total = fare + wait + fee, and rates come from RATES", () => {
  const q = quote(7.3, "SUV", true, 1.5);
  near(q.total, q.fare + q.wait + q.fee);
  near(q.fee, (q.fare + q.wait) * RATES.fee);
});
