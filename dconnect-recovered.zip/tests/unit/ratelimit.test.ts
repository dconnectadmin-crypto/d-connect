import { test } from "node:test";
import assert from "node:assert/strict";
import { rateLimited, clientIp } from "../../lib/ratelimit";

test("allows up to max hits then blocks", () => {
  const k = "t1-" + Math.random();
  for (let i = 0; i < 3; i++) assert.equal(rateLimited(k, 3, 1000), false);
  assert.equal(rateLimited(k, 3, 1000), true);
});
test("keys are independent", () => {
  const a = "t2a-" + Math.random(), b = "t2b-" + Math.random();
  for (let i = 0; i < 5; i++) rateLimited(a, 2, 1000);
  assert.equal(rateLimited(b, 2, 1000), false);
});
test("window expires", async () => {
  const k = "t3-" + Math.random();
  rateLimited(k, 1, 30); assert.equal(rateLimited(k, 1, 30), true);
  await new Promise(r => setTimeout(r, 60));
  assert.equal(rateLimited(k, 1, 30), false);
});
test("clientIp takes first x-forwarded-for entry, else 'local'", () => {
  assert.equal(clientIp(new Request("http://x", { headers: { "x-forwarded-for": "1.2.3.4, 5.6.7.8" } })), "1.2.3.4");
  assert.equal(clientIp(new Request("http://x")), "local");
});
