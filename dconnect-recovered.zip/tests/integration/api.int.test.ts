// HTTP integration tests. They need a running app + migrated/seeded PostgreSQL:
//   INTEGRATION_BASE_URL=http://localhost:3000 SEED_ADMIN_EMAIL=... SEED_ADMIN_PASSWORD=... npm run test:integration
// NOTE: sign-up is rate limited to 5/hour/IP, so each run uses 2 of those. Restart the dev server between many runs.
import { test } from "node:test";
import assert from "node:assert/strict";

const BASE = process.env.INTEGRATION_BASE_URL;
const ADMIN_EMAIL = process.env.SEED_ADMIN_EMAIL;
const ADMIN_PASSWORD = process.env.SEED_ADMIN_PASSWORD;
const skip = !BASE || !ADMIN_EMAIL || !ADMIN_PASSWORD ? "set INTEGRATION_BASE_URL, SEED_ADMIN_EMAIL, SEED_ADMIN_PASSWORD" : false;

class Client {
  cookie = "";
  async req(method: string, path: string, body?: unknown) {
    const res = await fetch(`${BASE}${path}`, { method, headers: { "content-type": "application/json", ...(this.cookie ? { cookie: this.cookie } : {}) }, body: body === undefined ? undefined : JSON.stringify(body), redirect: "manual" });
    for (const c of res.headers.getSetCookie()) {
      const kv = c.split(";")[0] ?? "";
      if (kv.startsWith("dc_session=")) this.cookie = kv === "dc_session=" ? "" : kv;
    }
    const data = (await res.json().catch(() => ({}))) as Record<string, unknown>;
    return { status: res.status, data };
  }
}

const run = Date.now().toString(36);
const pw = "Test-" + run + "-Aa1!";
const admin = new Client(), riderA = new Client(), riderB = new Client(), capX = new Client(), capY = new Client(), anon = new Client();
const ids: Record<string, string> = {};
const booking = { pickup: "Test Pickup Street", destination: "Test Destination Road", type: "ONE_WAY", category: "Mini", distanceKm: 5 };

test("unauthenticated API access is rejected", { skip }, async () => {
  assert.equal((await anon.req("GET", "/api/bookings")).status, 401);
  assert.equal((await anon.req("GET", "/api/admin/users")).status, 401);
});

test("admin can sign in; wrong password is rejected", { skip }, async () => {
  assert.equal((await new Client().req("POST", "/api/auth/login", { email: ADMIN_EMAIL, password: "wrong-password" })).status, 401);
  assert.equal((await admin.req("POST", "/api/auth/login", { email: ADMIN_EMAIL, password: ADMIN_PASSWORD })).status, 200);
});

test("admin creates two captains; two riders self-register", { skip }, async () => {
  for (const [k, c] of [["capX", capX], ["capY", capY]] as const) {
    const r = await admin.req("POST", "/api/admin/users", { name: k, email: `${k}-${run}@test.local`, password: pw, role: "CAPTAIN" });
    assert.equal(r.status, 201); ids[k] = String(r.data.id);
    assert.equal((await c.req("POST", "/api/auth/login", { email: `${k}-${run}@test.local`, password: pw })).status, 200);
  }
  for (const [k, c] of [["riderA", riderA], ["riderB", riderB]] as const) {
    assert.equal((await c.req("POST", "/api/auth/register", { name: k, email: `${k}-${run}@test.local`, password: pw })).status, 201);
  }
  assert.equal((await anon.req("POST", "/api/auth/register", { name: "x", email: "bad", password: "short" })).status, 400);
});

test("role boundaries: only admins reach admin APIs; riders cannot accept", { skip }, async () => {
  assert.equal((await riderA.req("GET", "/api/admin/users")).status, 403);
  assert.equal((await capX.req("GET", "/api/admin/users")).status, 403);
  assert.equal((await capX.req("POST", "/api/bookings", booking)).status, 403);
  assert.equal((await riderA.req("PATCH", "/api/bookings/does-not-matter", { action: "accept" })).status, 403);
});

let b1 = "";
test("booking validation and creation", { skip }, async () => {
  assert.equal((await riderA.req("POST", "/api/bookings", { ...booking, category: "Rocket" })).status, 400);
  assert.equal((await riderA.req("POST", "/api/bookings", { ...booking, type: "ROUND_TRIP" })).status, 400);
  const r = await riderA.req("POST", "/api/bookings", booking);
  assert.equal(r.status, 201); assert.equal(r.data.status, "REQUESTED"); assert.equal(typeof r.data.total, "number");
  b1 = String(r.data.id);
});

test("riders cannot see or cancel each other's bookings", { skip }, async () => {
  const list = await riderB.req("GET", "/api/bookings");
  assert.equal(list.status, 200); assert.ok(!(list.data as unknown as { id: string }[]).some(b => b.id === b1));
  assert.notEqual((await riderB.req("PATCH", `/api/bookings/${b1}`, { action: "cancel" })).status, 200);
  const mine = (await riderA.req("GET", "/api/bookings")).data as unknown as { id: string; status: string }[];
  assert.equal(mine.find(b => b.id === b1)?.status, "REQUESTED");
});

test("two captains accept at once: exactly one wins", { skip }, async () => {
  const [x, y] = await Promise.all([capX.req("PATCH", `/api/bookings/${b1}`, { action: "accept" }), capY.req("PATCH", `/api/bookings/${b1}`, { action: "accept" })]);
  assert.deepEqual([x.status, y.status].sort(), [200, 409]);
  ids.winner = x.status === 200 ? "capX" : "capY";
});

test("winner is busy, loser cannot complete, rider cannot cancel after acceptance", { skip }, async () => {
  const win = ids.winner === "capX" ? capX : capY, lose = ids.winner === "capX" ? capY : capX;
  const b2 = await riderA.req("POST", "/api/bookings", booking);
  assert.equal((await win.req("PATCH", `/api/bookings/${String(b2.data.id)}`, { action: "accept" })).status, 409);
  assert.equal((await lose.req("PATCH", `/api/bookings/${b1}`, { action: "complete" })).status, 409);
  assert.equal((await riderA.req("PATCH", `/api/bookings/${b1}`, { action: "cancel" })).status, 409);
  assert.equal((await riderA.req("PATCH", `/api/bookings/${String(b2.data.id)}`, { action: "cancel" })).status, 200);
});

test("captain location is visible to the rider only while the duty is ACCEPTED", { skip }, async () => {
  const win = ids.winner === "capX" ? capX : capY;
  assert.equal((await win.req("POST", "/api/location", { lat: 12.97, lng: 77.59 })).status, 200);
  assert.equal((await win.req("POST", "/api/location", { lat: 999, lng: 77.59 })).status, 400);
  assert.equal(((await riderA.req("GET", "/api/location")).data as unknown as unknown[]).length, 1);
  assert.equal(((await riderB.req("GET", "/api/location")).data as unknown as unknown[]).length, 0);
});

test("winner completes once; repeat completion is rejected; location hidden afterwards", { skip }, async () => {
  const win = ids.winner === "capX" ? capX : capY;
  const done = await win.req("PATCH", `/api/bookings/${b1}`, { action: "complete" });
  assert.equal(done.status, 200); assert.equal(done.data.status, "COMPLETED");
  assert.equal((await win.req("PATCH", `/api/bookings/${b1}`, { action: "complete" })).status, 409);
  assert.equal(((await riderA.req("GET", "/api/location")).data as unknown as unknown[]).length, 0);
});

test("disabled accounts lose access immediately and cannot log in", { skip }, async () => {
  assert.equal((await admin.req("PATCH", `/api/admin/users/${ids.capY}`, { active: false })).status, 200);
  assert.equal((await capY.req("GET", "/api/bookings")).status, 401);
  assert.equal((await new Client().req("POST", "/api/auth/login", { email: `capY-${run}@test.local`, password: pw })).status, 401);
});

test("logout invalidates the browser session", { skip }, async () => {
  assert.equal((await riderB.req("POST", "/api/auth/logout")).status, 200);
  assert.equal((await riderB.req("GET", "/api/bookings")).status, 401);
});
