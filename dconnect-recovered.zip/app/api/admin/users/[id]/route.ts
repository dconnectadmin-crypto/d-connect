import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { authorize } from "@/lib/auth";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const a = await authorize(["ADMIN"]);
  if (a.error) return a.error;
  const { id } = await params;
  const p = z.object({ active: z.boolean() }).safeParse(await req.json().catch(() => null));
  if (!p.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  if (id === a.user.id) return NextResponse.json({ error: "You cannot disable your own account." }, { status: 400 });
  const r = await db.user.updateMany({ where: { id }, data: { active: p.data.active } });
  if (r.count === 0) return NextResponse.json({ error: "User not found." }, { status: 404 });
  if (!p.data.active) await db.captainLocation.deleteMany({ where: { captainId: id } });
  return NextResponse.json({ ok: true });
}
